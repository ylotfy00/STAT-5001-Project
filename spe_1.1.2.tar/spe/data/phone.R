"phone" <- read.table('phone.txt')
names(phone) <- c('x','y','z')
