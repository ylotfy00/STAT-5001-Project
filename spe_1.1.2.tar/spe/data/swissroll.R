"swissroll" <- read.table('swissroll.txt')
names(swissroll) <- c('x','y','z')
